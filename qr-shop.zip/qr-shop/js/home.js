$(document).ready(function() {
    $('#shop-btn').click(function() {
        $('.button').show();
    });
});